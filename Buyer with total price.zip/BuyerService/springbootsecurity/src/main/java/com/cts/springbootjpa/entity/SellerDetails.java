package com.cts.springbootjpa.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SellerDetails {
	@GeneratedValue
	@Id
	private int sellerId;
	private String username;
	private String password;
	private String GSTIN;
	private String briefAboutCompany;
	private String postalAddress;
	private String website;
	private String emialID;
	private int contactNumber;
	public SellerDetails() 
	{
		
	}
	public SellerDetails(int sellerId, String username, String password, String gSTIN, String briefAboutCompany,
			String postalAddress, String website, String emialID, int contactNumber) {
		super();
		this.sellerId = sellerId;
		this.username = username;
		this.password = password;
		GSTIN = gSTIN;
		this.briefAboutCompany = briefAboutCompany;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emialID = emialID;
		this.contactNumber = contactNumber;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGSTIN() {
		return GSTIN;
	}
	public void setGSTIN(String gSTIN) {
		GSTIN = gSTIN;
	}
	public String getBriefAboutCompany() {
		return briefAboutCompany;
	}
	public void setBriefAboutCompany(String briefAboutCompany) {
		this.briefAboutCompany = briefAboutCompany;
	}
	public String getPostalAddress() {
		return postalAddress;
	}
	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmialID() {
		return emialID;
	}
	public void setEmialID(String emialID) {
		this.emialID = emialID;
	}
	public int getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "SellerDetails [sellerId=" + sellerId + ", username=" + username + ", password=" + password + ", GSTIN="
				+ GSTIN + ", briefAboutCompany=" + briefAboutCompany + ", postalAddress=" + postalAddress + ", website="
				+ website + ", emialID=" + emialID + ", contactNumber=" + contactNumber + "]";
	}
	
	

}
