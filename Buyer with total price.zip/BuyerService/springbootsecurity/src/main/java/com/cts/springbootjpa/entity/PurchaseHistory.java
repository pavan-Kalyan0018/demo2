package com.cts.springbootjpa.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class PurchaseHistory {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int purchaseHistoryId;
	private int itemId;
	private int numberOfItems;
	@Temporal(TemporalType.DATE) 
	@JsonFormat(pattern = "dd-mm-yyyy")
	private Date dateTime;
	private String remarks;
	@ManyToOne
	private BuyerDetails buyerdetails;
	@ManyToOne
	private TransactionHistory transactionhistory;
	public PurchaseHistory() 
	{ 
		
	}
	public PurchaseHistory(int purchaseHistoryId, int itemId, int numberOfItems, Date dateTime, String remarks,
			BuyerDetails buyerdetails, TransactionHistory transactionhistory) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.remarks = remarks;
		this.buyerdetails = buyerdetails;
		this.transactionhistory = transactionhistory;
	}
	public int getPurchaseHistoryId() {
		return purchaseHistoryId;
	}
	public void setPurchaseHistoryId(int purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public BuyerDetails getBuyerdetails() {
		return buyerdetails;
	}
	public void setBuyerdetails(BuyerDetails buyerdetails) {
		this.buyerdetails = buyerdetails;
	}
	public TransactionHistory getTransactionhistory() {
		return transactionhistory;
	}
	public void setTransactionhistory(TransactionHistory transactionhistory) {
		this.transactionhistory = transactionhistory;
	}
	@Override
	public String toString() {
		return "PurchaseHistory [purchaseHistoryId=" + purchaseHistoryId + ", itemId=" + itemId + ", numberOfItems="
				+ numberOfItems + ", dateTime=" + dateTime + ", remarks=" + remarks + ", buyerdetails=" + buyerdetails
				+ ", transactionhistory=" + transactionhistory + "]";
	}

}
