package com.cts.springbootjpa.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Sub_Category {
 @Id
 private int subCategoryId;
 @ManyToOne
 private  Category category;
 private String subCategoryName;
 private String briefDetails;
 private String gstNo;
 public Sub_Category() 
 { 
	 
 }
public Sub_Category(int subCategoryId, Category category, String subCategoryName, String briefDetails, String gstNo) {
	super();
	this.subCategoryId = subCategoryId;
	this.category = category;
	this.subCategoryName = subCategoryName;
	this.briefDetails = briefDetails;
	this.gstNo = gstNo;
}
public int getSubCategoryId() {
	return subCategoryId;
}
public void setSubCategoryId(int subCategoryId) {
	this.subCategoryId = subCategoryId;
}
public Category getCategory() {
	return category;
}
public void setCategory(Category category) {
	this.category = category;
}
public String getSubCategoryName() {
	return subCategoryName;
}
public void setSubCategoryName(String subCategoryName) {
	this.subCategoryName = subCategoryName;
}
public String getBriefDetails() {
	return briefDetails;
}
public void setBriefDetails(String briefDetails) {
	this.briefDetails = briefDetails;
}
public String getGstNo() {
	return gstNo;
}
public void setGstNo(String gstNo) {
	this.gstNo = gstNo;
}
@Override
public String toString() {
	return "Sub_Category [subCategoryId=" + subCategoryId + ", category=" + category + ", subCategoryName="
			+ subCategoryName + ", briefDetails=" + briefDetails + ", gstNo=" + gstNo + "]";
}


}
